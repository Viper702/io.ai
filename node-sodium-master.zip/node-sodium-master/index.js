/**
 * Created by bmf on 11/2/13.
 */
 /* jslint node: true */
'use strict';

module.exports = require('./lib/sodium');
